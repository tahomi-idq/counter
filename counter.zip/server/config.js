export const secret = "some_secret";
export const counterClearInterval = 60000;