export const Roles = {
    reader:"READER",
    admin:"ADMIN",
}